from .ollama_client import OllamaClient


DEFAULT_MODEL = "qwen2.5:latest"  # You can switch to "llama3.2:latest" if you prefer


def generate_optimization_recommendations(summary_text: str, model: str = DEFAULT_MODEL) -> str:
    prompt = f"""
You are an AI Facility Optimization Expert for large buildings worldwide.

You are given a summary of real-time IoT data for a facility. 
You must generate:

1) Energy optimization steps
   - e.g., turn off non-critical lights after 6 PM when occupancy is zero
   - optimize HVAC schedules
   - reduce unnecessary water flow

2) Cost impact explanation
   - where is money being wasted?
   - which actions will reduce cost the most?

3) Efficiency improvement ideas
   - occupancy-based automation (lights & HVAC)
   - peak vs non-peak operation suggestions

4) Risk reduction recommendations
   - which parameters indicate risk of equipment fault or burnout?
   - what proactive maintenance or thresholds should be applied?

5) A short prioritized checklist for the facility manager.

Be specific and practical. Write in clear bullet points.

SUMMARY:
{summary_text}
    """.strip()

    client = OllamaClient()
    return client.generate(model=model, prompt=prompt, stream=False)
