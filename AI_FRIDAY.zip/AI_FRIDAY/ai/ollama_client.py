import requests
from typing import Optional


class OllamaClient:
    def __init__(self, base_url: str = "http://localhost:11434"):
        self.base_url = base_url.rstrip("/")

    def generate(
        self,
        model: str,
        prompt: str,
        stream: bool = False,
        options: Optional[dict] = None,
    ) -> str:
        payload = {
            "model": model,
            "prompt": prompt,
            "stream": stream,
        }
        if options:
            payload["options"] = options

        url = f"{self.base_url}/api/generate"
        resp = requests.post(url, json=payload)
        resp.raise_for_status()
        data = resp.json()

        text = data.get("response", "")

        # Remove thinking tags if any (for reasoning models)
        cleaned = text.replace("<think>", "").replace("</think>", "")
        return cleaned
