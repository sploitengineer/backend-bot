import pandas as pd
import numpy as np


def apply_severity_rules(df: pd.DataFrame) -> pd.DataFrame:
    conditions = [
        (df["temperature_c"] > 31)
        | (df["vibration_level"] > 4.5)
        | (df["hvac_load_kw"] > 7.5),

        (df["light_usage_watts"] > 250)
        | (df["water_flow_lpm"] > 18),

        (df["occupancy"] == 0) & (df["light_usage_watts"] > 120),
    ]
    choices = ["critical", "medium", "low"]
    df["severity"] = np.select(conditions, choices, default="low")
    return df
