import pandas as pd


def compute_cost_projection(df: pd.DataFrame) -> pd.Series:
    """
    Cumulative cost projection over time.
    """
    return df["cost_per_minute"].cumsum()


def compute_efficiency_index(df: pd.DataFrame) -> float:
    """
    Simple efficiency score: more occupancy per energy used = better.
    """
    total_energy = (df["light_usage_watts"] / 1000.0).sum() + df["hvac_load_kw"].sum()
    occupied_samples = df[df["occupancy"] == 1].shape[0]

    if total_energy == 0:
        return 0.0

    efficiency = occupied_samples / total_energy
    return round(efficiency, 3)


def compute_fault_risk_index(df: pd.DataFrame) -> float:
    """
    Fault risk based on vibration + high temperature + critical occurrences.
    Returns a score between 0 and 1 (approx).
    """
    vibration_score = min(df["vibration_level"].mean() / 5.0, 1.0)
    temp_score = min(max(df["temperature_c"].mean() - 24, 0) / 10.0, 1.0)
    critical_ratio = (df["severity"] == "critical").mean()

    risk = 0.4 * vibration_score + 0.3 * temp_score + 0.3 * critical_ratio
    return round(float(risk), 3)


def compute_severity_distribution(df: pd.DataFrame) -> pd.Series:
    return df["severity"].value_counts(normalize=False)


def build_summary_for_ai(df: pd.DataFrame) -> str:
    """
    Summarize metrics for LLM prompt.
    """
    cost_total = df["cost_per_minute"].sum()
    eff = compute_efficiency_index(df)
    risk = compute_fault_risk_index(df)
    sev_counts = df["severity"].value_counts().to_dict()

    after_6pm_lights = df[
        (df["timestamp"].dt.hour >= 18) &
        (df["light_usage_watts"] > 100) &
        (df["occupancy"] == 0)
    ].shape[0]

    summary = f"""
Total records analyzed: {len(df)}
Total operational cost (approx): {cost_total:.2f} units
Efficiency index: {eff}
Fault risk index (0-1): {risk}
Severity distribution: {sev_counts}
Lights ON after 6 PM with no occupancy: {after_6pm_lights} samples
Typical temperature range: {df['temperature_c'].min():.1f} – {df['temperature_c'].max():.1f} °C
Typical HVAC load range: {df['hvac_load_kw'].min():.1f} – {df['hvac_load_kw'].max():.1f} kW
    """.strip()

    return summary
