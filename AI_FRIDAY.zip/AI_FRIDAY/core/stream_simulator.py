import time
import pandas as pd
from typing import Generator, Tuple


def split_initial_and_stream(df: pd.DataFrame, initial_size: int = 1000
                             ) -> Tuple[pd.DataFrame, pd.DataFrame]:
    """
    Split the dataframe into:
    - initial historical data
    - stream_data (for live updates)
    """
    initial = df.iloc[:initial_size].copy()
    stream_part = df.iloc[initial_size:].copy()
    return initial, stream_part


def stream_batches(df_stream: pd.DataFrame,
                   batch_size: int = 10,
                   sleep_seconds: float = 1.0
                   ) -> Generator[pd.DataFrame, None, None]:
    """
    Yield data in batches to simulate real-time streaming.
    """
    for start in range(0, len(df_stream), batch_size):
        end = start + batch_size
        batch = df_stream.iloc[start:end]
        yield batch
        time.sleep(sleep_seconds)
