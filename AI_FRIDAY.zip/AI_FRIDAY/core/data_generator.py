import os
import pandas as pd
import numpy as np
from datetime import datetime, timedelta

DATA_DIR = os.path.join(os.path.dirname(os.path.dirname(__file__)), "data")
os.makedirs(DATA_DIR, exist_ok=True)

DATA_PATH = os.path.join(DATA_DIR, "iot_data.csv")


def generate_iot_dataset(num_rows: int = 5000) -> pd.DataFrame:
    """
    Generate synthetic IoT dataset for a facility.
    """
    base_time = datetime.now().replace(microsecond=0)

    timestamps = [base_time + timedelta(seconds=i) for i in range(num_rows)]

    # Simulate realistic values
    light_usage = np.random.randint(20, 300, num_rows)
    occupancy = np.random.choice([0, 1], size=num_rows, p=[0.4, 0.6])
    water_flow = np.random.uniform(0.2, 25.0, num_rows)
    temperature = np.random.uniform(20.0, 34.0, num_rows)
    hvac_load = np.random.uniform(0.5, 8.5, num_rows)
    vibration = np.random.uniform(0.05, 5.5, num_rows)

    df = pd.DataFrame({
        "timestamp": timestamps,
        "light_usage_watts": light_usage,
        "occupancy": occupancy,
        "water_flow_lpm": water_flow,
        "temperature_c": temperature,
        "hvac_load_kw": hvac_load,
        "vibration_level": vibration,
    })

    # Approximate per-minute operational cost
    df["cost_per_minute"] = (
        df["light_usage_watts"] * 0.00018
        + df["water_flow_lpm"] * 0.045
        + df["hvac_load_kw"] * 0.32
    )

    # Severity – rule-based for now
    df = add_severity(df)

    return df


def add_severity(df: pd.DataFrame) -> pd.DataFrame:
    """
    Add severity column based on risk rules (low/medium/critical).
    """
    conditions = [
        # CRITICAL: overheating, extreme vibration, or very high HVAC load
        (df["temperature_c"] > 31)
        | (df["vibration_level"] > 4.5)
        | (df["hvac_load_kw"] > 7.5),

        # MEDIUM: high light or water usage, but not critical
        (df["light_usage_watts"] > 250)
        | (df["water_flow_lpm"] > 18),

        # LOW: lights on without occupancy, minor waste
        (df["occupancy"] == 0) & (df["light_usage_watts"] > 120),
    ]
    choices = ["critical", "medium", "low"]

    df["severity"] = np.select(conditions, choices, default="low")

    return df


def save_dataset(df: pd.DataFrame, path: str = DATA_PATH) -> None:
    df.to_csv(path, index=False)


def load_or_generate_dataset(path: str = DATA_PATH, num_rows: int = 5000) -> pd.DataFrame:
    """
    Load dataset if already exists, otherwise generate a new one.
    """
    if os.path.exists(path):
        df = pd.read_csv(path, parse_dates=["timestamp"])
    else:
        df = generate_iot_dataset(num_rows)
        save_dataset(df, path)
    return df


if __name__ == "__main__":
    df = generate_iot_dataset()
    save_dataset(df)
    print("Dataset saved to:", DATA_PATH)
    print("\n=== df.head() ===")
    print(df.head())
