import time
import streamlit as st
import pandas as pd
import matplotlib.pyplot as plt

from core.data_generator import load_or_generate_dataset
from core.stream_simulator import split_initial_and_stream, stream_batches
from core.analytics import (
    compute_cost_projection,
    compute_efficiency_index,
    compute_fault_risk_index,
    compute_severity_distribution,
    build_summary_for_ai,
)
from ai.recommender import generate_optimization_recommendations

st.set_page_config(
    page_title="AstraSense – Smart Facility AI Command Center",
    layout="wide",
)

st.title("🏢 AstraSense – Smart Facility AI Command Center")

st.markdown(
    """
Real-time IoT monitoring + AI optimization for energy, cost, and risk.
"""
)

# Load or generate data
df_full = load_or_generate_dataset()

# Split initial and streaming part
initial_df, stream_df = split_initial_and_stream(df_full, initial_size=1000)

# Initialize session state for live streaming
if "live_df" not in st.session_state:
    st.session_state.live_df = initial_df.copy()
if "stream_started" not in st.session_state:
    st.session_state.stream_started = False


# Sidebar summary
with st.sidebar:
    st.header("📌 Current Snapshot")
    eff_index = compute_efficiency_index(st.session_state.live_df)
    risk_index = compute_fault_risk_index(st.session_state.live_df)
    sev_dist = compute_severity_distribution(st.session_state.live_df)

    st.metric("Efficiency Index", eff_index)
    st.metric("Fault Risk Index (0-1)", risk_index)
    st.write("Severity Counts:")
    st.write(sev_dist.to_dict())


# Main layout
placeholder = st.empty()

start_stream = st.button("▶ Start Real-Time Stream", disabled=st.session_state.stream_started)

if start_stream:
    st.session_state.stream_started = True

if st.session_state.stream_started:
    # Stream 10 rows per second and update dashboard
    for batch in stream_batches(stream_df, batch_size=10, sleep_seconds=1.0):
        st.session_state.live_df = pd.concat([st.session_state.live_df, batch]).reset_index(drop=True)

        with placeholder.container():
            st.subheader("📈 Real-Time IoT Data (Latest 50 rows)")
            st.dataframe(st.session_state.live_df.tail(50))

            # Create columns for charts
            col1, col2 = st.columns(2)

            with col1:
                st.write("### Light Usage vs Time")
                fig1, ax1 = plt.subplots()
                recent = st.session_state.live_df.tail(300)
                ax1.plot(recent["timestamp"], recent["light_usage_watts"])
                ax1.set_ylabel("Watts")
                ax1.tick_params(axis='x', rotation=45)
                st.pyplot(fig1)

                st.write("### Severity Distribution (Live)")
                sev_counts = compute_severity_distribution(st.session_state.live_df)
                st.bar_chart(sev_counts)

            with col2:
                st.write("### Vibration Level (Fault Risk Indicator)")
                fig2, ax2 = plt.subplots()
                recent = st.session_state.live_df.tail(300)
                ax2.plot(recent["timestamp"], recent["vibration_level"])
                ax2.set_ylabel("Vibration level")
                ax2.tick_params(axis='x', rotation=45)
                st.pyplot(fig2)

                st.write("### Cumulative Cost Projection")
                cost_series = compute_cost_projection(st.session_state.live_df)
                st.line_chart(cost_series)

            # AI Recommendations area
            st.subheader("🤖 AI Optimization Recommendations")
            if st.button("Generate AI Insights"):
                with st.spinner("Analyzing usage patterns and generating suggestions..."):
                    summary = build_summary_for_ai(st.session_state.live_df)
                    ai_text = generate_optimization_recommendations(summary)
                st.success("AI recommendations generated.")
                st.write(ai_text)

        # Let Streamlit refresh UI
        st.rerun()

# If stream not started yet, show base analytics
if not st.session_state.stream_started:
    st.subheader("📊 Historical Baseline (Initial 1000 rows)")
    st.dataframe(initial_df.head())

    col1, col2, col3 = st.columns(3)
    with col1:
        st.metric("Efficiency Index", compute_efficiency_index(initial_df))
    with col2:
        st.metric("Fault Risk Index (0-1)", compute_fault_risk_index(initial_df))
    with col3:
        st.metric("Records Loaded", len(initial_df))

    st.write("### Baseline Severity Distribution")
    st.bar_chart(compute_severity_distribution(initial_df))

    st.write("### Baseline Cost Projection")
    st.line_chart(compute_cost_projection(initial_df))
